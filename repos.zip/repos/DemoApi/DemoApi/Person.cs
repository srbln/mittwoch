﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace DemoApi
{
    public class Person
    {
        public int Id { get; set; }
        public string Name { get; set; }

        [JsonIgnore]
        public DateTime Birthday { get; set; }

        public int OfficeId { get; set; }

        public List<string> Languages { get; set; }
           
        public int Age 
        {   get
            {
                return (DateTime.Now - Birthday).Days / 365;
            }
            //private set { this.Age = value; }
        }
    }
}
