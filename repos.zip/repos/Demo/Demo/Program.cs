﻿using System;

namespace Demo 
{ 
    internal class Program
    {
        static void Main(string[] args)
        {
            Greeter greeter = new Greeter("casual");

            Console.WriteLine(greeter.Greet());           
        }

        
    }
}