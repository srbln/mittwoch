﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo
{
    public class Greeter
    {
        public IGreeter greeter { get; set; }

        public String Formality { get; set; }

        public Greeter(IGreeter g) {
            greeter = g;
        }

        public String Greet()
        {
            //return greeter.Greet();

            if (Formality == "casual")
                return "Hey";
            else if (Formality == "formal")
                return "Guten Tag";
            else if (Formality == "friend")
                return "Handschlag";
            return "Hallo";

        }
    }
}
